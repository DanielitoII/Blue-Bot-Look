module.exports.help = {
  name: 'ban',
  descreption: "bans a member",
  aliases: [""]
  }

const {MessageEmbed} = require('discord.js')
module.exports.run = async function(client, message,args) {
        if (!message.member.hasPermission('BAN_MEMBERS')) {
            return message.channel.send(`You are unable to ban members`)
        }
            const user = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
    
    if(!user) {
      return message.channel.send("Please Mention the person to who you want to ban")
    }
    
    if(message.mentions.users.first().bot) {
      return message.channel.send("You can not ban bots")
    }
    
    if(message.author.id === user.id) {
      return message.channel.send("You can not ban yourself")
    }
    
    if(user.id === message.guild.owner.id) {
      return message.channel.send(" you cant ban server owner -_-")
    }
    
    const reason = args.slice(1).join(" ")
    
    if(!reason) {
      return message.channel.send("Please provide reason to ban")
    }
        if (!args[0]) {
            return message.channel.send(`Please mention a user!`)
        }
        const member = message.mentions.members.users.first() || message.guild.members.cache.get(args[0]);

        try {
            await member.ban();
            await message.channel.send(`${member} has been banned!`)
             
        } catch (e) {
            return message.channel.send(`User is not in the server!`)
        }

}