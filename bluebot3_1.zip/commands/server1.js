
module.exports.help = {
    name: "dash",
    decreption: "dash",
    aliases: []
}

module.exports.run = async function(client, message, args) {
    if (message.author.id == 773031033850953748) {
      message.reply("||https://bluebot3.siddarth0078.repl.co||")
    } else {
      message.reply("This cmd is owner only now it soon will be public")
    }
  };